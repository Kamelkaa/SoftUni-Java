package restaurant.entities.drinks.interfaces;

public interface Beverages {
    String getName();

    int getCounter();

    double getPrice();

    String getBrand();
}
