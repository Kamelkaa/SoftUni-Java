package restaurant.core.interfaces;

public interface Engine {
    void run();
}
