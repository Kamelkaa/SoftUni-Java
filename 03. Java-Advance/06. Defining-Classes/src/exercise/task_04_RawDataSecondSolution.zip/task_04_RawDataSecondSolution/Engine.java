package exercise.task_04_RawDataSecondSolution;

public class Engine {
    private int speed;
    private int power;

    public Engine(int power) {
        this.power = power;
    }

    public int getPower() {
        return power;
    }
}
