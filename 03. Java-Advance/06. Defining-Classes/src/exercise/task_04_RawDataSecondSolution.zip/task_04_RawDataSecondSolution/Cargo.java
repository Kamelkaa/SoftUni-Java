package exercise.task_04_RawDataSecondSolution;

public class Cargo {
    private int weight;
    private String type;

    public Cargo( String type) {
        this.type = type;
    }
}
